<?php
session_start(); // Inicia a sessão para acessar as variáveis de sessão
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Truco IFPR</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
        .user-info {
            position: absolute;
            top: 10px;
            left: 10px;
            padding: 10px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <!-- DIV do Cabeçalho (Logotipo) -->
    <div class="p-5 bg-light text-success text-center">
        <img src="img/ifpr_logo.png" width="10%">
    </div>

    <!-- Exibição das informações do usuário -->
    <?php if(isset($_SESSION['emailUsuario']) && isset($_SESSION['nomeUsuario'])): ?>
        <div class="user-info">
            <p>Usuário: <?php echo $_SESSION['nomeUsuario']; ?></p>
            <!-- Exibir mais informações aqui, como email, sexo, etc., conforme necessário -->
            <!-- Exemplo: <p>Email: <?php echo $_SESSION['emailUsuario']; ?></p> -->
            <!-- <a href="logout.php" class="btn btn-outline-danger btn-sm">Sair</a> -->
        </div>
    <?php endif; ?>

    <!-- Bloco para a Barra de Navegação (NavBar) -->
    <nav class="navbar navbar-expand-sm bg-success navbar-dark sticky-top">
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php" title="Home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="formLogin.php" title="Acessar o Sistema">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="formUsuario.php" title="Acessar o Sistema">Cadastrar usuário</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="formCampeonato.php">Cadastrar campeonatos</a>
                </li>   
            </ul>
        </div>
    </nav>

    <!-- DIV Container (Principal) -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-12">
                <!-- Conteúdo principal da página continua aqui -->
