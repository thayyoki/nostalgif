<?php

    $servidorBD = "localhost";
    $usuarioBD  = "root";
    $senhaBD    = "";
    $baseDados  = "nome_do_banco";

    //Função para estabelecer conexão com o BD
    $link = mysqli_connect($servidorBD, $usuarioBD, $senhaBD, $baseDados);

    if(!$link){
        echo "<p>Erro ao tentar conectar à Base de Dados $baseDados .</p>";
    }

?>