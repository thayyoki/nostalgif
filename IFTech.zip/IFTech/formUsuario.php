<?php include("header.php"); ?>
    
    <h2>Formulário para cadastro de Usuarios</h2>
    <p>*Campo Obrigatório</p>
    <br>

    <form action="cadastrarUsuario.php" method="POST" enctype="multipart/form-data">

        <div class="form-group">
            <label for="fotoUsuario">Foto:</label>
            <input type="file" class="btn btn-link" name="fotoUsuario">
        </div>

        <div class="form-floating mb-3 mt-3">   
            <input type="text" class="form-control" placeholder="Informe o seu nome Completo" name="nomeUsuario">
            <label for="nomeUsuario" class="form-label">*Nome:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Informe o CPF" name="cpfUsuario" maxlength="14" id="cpfUsuario">
            <label for="cpfUsuario" class="form-label" id="cpfUsuario">*CPF:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Informe o SIAPE" name="siapeUsuario" maxlength="7">
            <label for="siapeUsuario" class="form-label" id="siapeUsuario">SIAPE:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Informe o TELEFONE" name="telefoneUsuario" id="telefoneUsuario">
            <label for="telefoneUsuario" class="form-label" id="telefoneUsuario">*Telefone:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <textarea class="form-control" placeholder="Informe o Endereço" name="enderecoUsuario"></textarea>
            <label for="enderecoUsuario" class="form-label">Endereço:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <select class="form-select" name="estadoUsuario">
                <option value="PR">Paraná</option>
                <option value="SC">Santa Catarina</option>
                <option value="RS">Rio Grande do Sul</option>
            </select>
            <label for="estadoUsuario" class="form-label">Estado:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <input type="date" class="form-control" placeholder="Informe a data de nascimento" name="dtNascUsuario">
            <label for="dtNascUsuario" class="form-label">*Data de Nascimento:</label>
        </div>

        <label for="sexoUsuario">Sexo:</label>
        <div class="form-check">
            <label class="form-check-label">
                <input type="radio" class="form-check-input" name="sexoUsuario" value="F" checked>Feminino
            </label>
        </div>
        <div class="form-check">
            <label class="form-check-label">
                <input type="radio" class="form-check-input" name="sexoUsuario" value="M">Masculino
            </label>
        </div>
        <br>
        
        <div class="form-floating mb-3 mt-3">
            <input type="email" class="form-control" placeholder="Informe o email" name="emailUsuario" required>
            <label for="emailUsuario" class="form-label">*Email:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control" placeholder="Informe uma Senha" name="senhaUsuario" maxlength="10">
            <label for="senhaUsuario" class="form-label">*Senha:</label>
        </div>

        <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control" placeholder="Confirme a Senha" name="confirmarSenhaUsuario" maxlength="10">
            <label for="confirmarSenhaUsuario" class="form-label">*Confirme a Senha:</label>
        </div>

        <div style="margin-top:30px; margin-bottom:30px;">
            <button type="submit" class="btn btn-outline-success">Cadastrar</button>
        </div>

    </form>

<?php include("footer.php");