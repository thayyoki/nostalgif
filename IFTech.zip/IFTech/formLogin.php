<?php include("header.php"); ?>
    
    <h2>Login de usuário:</h2>

    <form action="login.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3 mt-3">
            <label for="email" class="form-label">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="emailUsuario" required>
        </div>
        <div class="mb-3">
            <label for="pwd" class="form-label">Password:</label>
            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="senhaUsuario" required>
        </div>
        <button type="submit" class="btn btn-success">Submit</button>
    </form>

<?php include("footer.php"); ?>
               